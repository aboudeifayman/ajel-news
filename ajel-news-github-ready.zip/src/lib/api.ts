const API_BASE_URL =
  import.meta.env.VITE_API_URL || 'http://localhost:3000';

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data?.error || 'حدث خطأ أثناء الاتصال بالخادم');
  }

  return data;
}

export interface SynthesisRequest {
  category?: string;
  region?: string;
  focus?: string;
}

export interface VerifyRequest {
  claim: string;
  source?: string;
}

export interface TranslateRequest {
  rawText: string;
  targetFormat?: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export function generateNewsSynthesis(data: SynthesisRequest) {
  return request('/api/news/synthesis', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export function verifyNews(data: VerifyRequest) {
  return request('/api/news/verify', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export function translateAndSummarize(data: TranslateRequest) {
  return request('/api/news/translate-summarize', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export function chatWithAI(messages: ChatMessage[], currentTopic?: string) {
  return request('/api/news/chat', {
    method: 'POST',
    body: JSON.stringify({ messages, currentTopic }),
  });
}

export function checkAPIHealth() {
  return request('/health');
}
